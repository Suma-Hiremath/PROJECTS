package register.login.page;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.concurrent.ThreadPoolExecutor.DiscardOldestPolicy;

import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServelet
 */
@WebServlet("/register")
public class RegistrationServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		 String uname=request.getParameter("name");
		 String uemail=request.getParameter("email");
		 String pwd=request.getParameter("pass");
		 String umobile=request.getParameter("contact");
//		 RequestDispatcher dispatcher=null;
		 Connection connection=null;
		RequestDispatcher dispatcher=null;
		 
//		 PrintWriter out=response.getWriter();
//		 out.print(uname);     
//		 out.print(uemail);
//		 out.print(pwd);      
//		 out.print(umobile);
		
		 try {
			    Class.forName("com.mysql.cj.jdbc.Driver");
				 connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/jspider", "root", "root");
				PreparedStatement preparedstatement=connection.prepareStatement("insert into users(uname,upwd, uemail,umobile) values(?,?,?,?)");
				preparedstatement.setString(1,uname);
				preparedstatement.setString(2, uemail);
				preparedstatement.setString(3, umobile);
				preparedstatement.setString(4, pwd);
				preparedstatement.execute();
			    int rowcount=preparedstatement.executeUpdate();
			    dispatcher=request.getRequestDispatcher("registration.jsp");
			if(rowcount>0)
			{
				request.setAttribute("status", "sucess");
				
			}
			else
			{
				request.setAttribute("status", "failed");

			}
			dispatcher.forward(request, response);
			
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		 finally
		 {
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("data saved");
		 }
		 
		 
	}

}
